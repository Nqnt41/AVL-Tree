#include <iostream>
#include <iomanip>
#include <queue>
#include <string>
#include <vector>
#include <unordered_map>
using namespace std;

// Ryan Coveny's Project 1 AVL Tree Submission:

class MyAVLTree {
    /// Node definition:
    /// Private Node struct used for MyAVLTree functions.
private:
    struct Node {
        string subName; // Submitted name inputted by the user.
        int idNum; // ID number inputted by the user.
        int height; // Height initially equal to one when node set as the leaf.
        Node *left; // Left node established by the insert function below.
        Node *right; // Right node established by the insert function below.
        Node(string x, int y): subName(x), idNum(y), height(1), left(nullptr), right(nullptr) {}
    };
    Node* root = nullptr;
    int numNodes = 0;



    /// Private Helper Functions:
    /// Helper functions to be called within other functions of the MyAVLTree class.
    // Helper function to see if an inputted name is allowed.
    bool isValidName(string name) {
        // If something other than a letter or space is found while traversing the input, return false.
        for (int i = 0; i < name.size(); i++) {
            if ((!isalpha(name[i]) && name[i] != ' ')) {
                return false;
            }
        }
        return true;
    }

    // Helper function to see if an inputted ID number is allowed.
    bool isValidId(string id) {
        // If the inputted ID is eight characters or fewer and only contains digits, return true.
        if (id.size() == 8 && isValidNumber(id)) {
            return true;
        }
        else {
            return false;
        }
    }

    // Helper function that removes the quotation marks from submitted names.
    string parseName(string name) {
        // If quotation marks found at beginning and end of the input, remove them and return the parsed name.
        string parsedName;
        if (name.size() > 2 && name[0] == '"' && name[name.size() - 1] == '"') {
            parsedName = name.substr(1, name.size() - 2);
            return parsedName;
        }
            // If there are no quotation marks, return the original name.
        else {
            return name;
        }
    }

    // Helper function which helps add leading zeroes for cases when an inputted ID number is less than 10000000.
    string printLeadingZeros(int idNum) {
        // Needs seven leading zeros
        if (idNum < 10) {
            return "0000000";
        }
            // Needs six leading zeros
        else if (idNum < 100) {
            return "000000";
        }
            // Needs five leading zeros
        else if (idNum < 1000) {
            return "00000";
        }
            // Needs four leading zeros
        else if (idNum < 10000) {
            return "0000";
        }
            // Needs three leading zeros
        else if (idNum < 100000) {
            return "000";
        }
            // Needs two leading zeros
        else if (idNum < 1000000) {
            return "00";
        }
            // Needs one leading zero
        else if (idNum < 10000000) {
            return "0";
        }
            // Needs no leading zeros
        else {
            return "";
        }
    }

    // Helper function to get the inorder successor
    Node* findInorderSuccessor(Node* node) {
        // Move one node to the right of the inputted node and then as far left as possible. Return the final node.
        Node* currentNode = node;
        currentNode = currentNode->right;
        while (currentNode->left != nullptr) {
            currentNode = currentNode->left;
        }
        return currentNode;
    }

    // Helper function providing access to height and setting height equal to zero if there is no node called.
    int accessHeight(Node* node) {
        if (node == nullptr) {
            return 0;
        }
        else {
            return node->height;
        }
    }

    // Helper function to find the height of a node.
    int findHeight(Node* node) {
        // Return a height of zero if there is no node inputted.
        if (node == nullptr) {
            return 0;
        }
            // Find heights of the left and right, return whichever final height is greater + 1.
        else {
            // Find the height of the node to the left of the main node, if it exists.
            int leftHeight = accessHeight(node->left);
            // Find the height of the node to the right of the main node, if it exists.
            int rightHeight = accessHeight(node->right);
            // Decide whether to return the height based on the left or right, depending on which is greater.
            if (leftHeight > rightHeight) {
                return leftHeight + 1;
            }
            else {
                return rightHeight + 1;
            }
        }
    }

    // Helper function to find the balance for a node.
    int findBalance(Node* node) {
        // If no node inputted, return zero.
        if (node == nullptr) {
            return 0;
        }
        else {
            // Subtract height of the left subtree with the height of the right subtree, return the result.
            int leftSubtree = findHeight(node->left);
            int rightSubtree = findHeight(node->right);
            int balance = leftSubtree - rightSubtree;
            return balance;
        }
    }

    // Helper function for left rotate.
    Node* rotateLeft(Node *node) {
        // nodeR represents the inputted node's right child, nodeRL represents nodeR's left child.
        Node* nodeR = node->right;
        Node* nodeRL = nodeR->left;
        // Move original node so that it is nodeR's new left child.
        nodeR->left = node;
        // Move nodeR's original left child so that it is now the inputted node's right child.
        node->right = nodeRL;

        // Update the height for both changed nodes.
        node->height = findHeight(node);
        nodeR->height = findHeight(nodeR);
        return nodeR;
    }

    // Helper function for right rotate.
    Node* rotateRight(Node *node) {
        // nodeL represents the inputted node's left child, nodeLR represents nodeL's right child.
        Node* nodeL = node->left;
        Node* nodeLR = nodeL->right;
        // Move original node so that it is nodeL's new right child.
        nodeL->right = node;
        // Move nodeL's original right child so that it is now the inputted node's left child.
        node->left = nodeLR;
        // Update the height for both changed nodes.
        node->height = findHeight(node);
        nodeL->height = findHeight(nodeL);
        return nodeL;
    }

    // Helper function for a left-right rotation.
    Node* rotateLeftRight(Node *node) {
        // Do a left rotation on the inputted node's left node, followed by a right rotation on the inputted node.
        node->left = rotateLeft(node->left);
        return rotateRight(node);
    }

    // Helper function for a right-left rotation.
    Node* rotateRightLeft(Node *node) {
        // Do a right rotation on the inputted node's right node, followed by a left rotation on the inputted node.
        node->right = rotateRight(node->right);
        return rotateLeft(node);
    }

    // Helper function used for testing - outputs if a tree is or is not balanced.
    bool isBalancedTree() {
        bool isBalanced = true;
        isBalancedTreeFunction(root, isBalanced);
        if (isBalanced) {
            cout << "Tree is balanced!" << endl;
        }
        return isBalanced;
    }
    void isBalancedTreeFunction(Node* node, bool& isBalanced) {
        // End if no tree was inputted.
        if (node == nullptr) {
            return;
        }
        // Do an inorder traversal through each node - if one is found with a faulty balance, output the node's ID and the balance.
        isBalancedTreeFunction(node->left, isBalanced);
        int balance = findBalance(node);
        if (balance > 1 || balance < -1) {
            cout << node->idNum << " is unbalanced - balance is " << balance << endl;
            isBalanced = false;
        }
        isBalancedTreeFunction(node->right, isBalanced);
    }



public:
    /// Public Helper Functions:
    /// The helper functions that were designed to be used in main.
    // Helper function to split a getline string into parts.
    void getInputs(string fullInput, string& inputFunction, string& inputParameterOne, string& inputParameterTwo) {
        // Counts number of spaces in the full input attained by the getline function - decides next step of function.
        int numSpaces = 0;
        int quotationIndexOne = -2;
        int quotationIndexTwo = -2;
        int numDigits = 0;
        for (int i = 0; i < fullInput.size(); i++) {
            if (fullInput[i] == ' ') {
                numSpaces++;
            }
            if (fullInput[i] == '"' && quotationIndexOne == -2) {
                quotationIndexOne = i;
            }
            else if (fullInput[i] == '"' && quotationIndexOne != -2) {
                quotationIndexTwo = i;
            }
            if (isdigit(fullInput[i])) {
                numDigits++;
            }
        }

        // If there are no spaces, a function with no parameters is called - set the name of function to inputFunction.
        // Applies to printPreorder, printInorder, printPostorder, and printLevelCount.
        if (numSpaces == 0) {
            inputFunction = fullInput;
        }

            // If there is one space and the only parameter is an ID number, enter this else if statement.
            // Used for functions remove, search ID, and removeInorder.
        else if (numSpaces == 1 && numDigits > 0) {
            inputFunction = fullInput.substr(0, fullInput.find(' '));
            inputParameterOne = fullInput.substr( fullInput.find(' ') + 1, fullInput.size());
        }

            // If the second quotation's index is the same as the final index of the full input, a function with a name parameter is called.
            // Used for search NAME.
        else if (numSpaces >= 1 && numDigits == 0) {
            inputFunction = fullInput.substr(0, fullInput.find(' '));
            inputParameterOne = fullInput.substr(fullInput.find(' ') + 1, fullInput.size());
        }

            // If the second quotation's index is not at the end of the input, there are two parameters: NAME and ID.
            // Used for the insert function.
        else if (quotationIndexTwo != fullInput.size() - 1 && quotationIndexTwo != -2) {
            // For loop used to assign each part of fullInput to the function name and the two parameters.
            // Remove quotation marks from names if necessary.
            inputFunction = fullInput.substr(0, fullInput.find(' '));
            inputParameterOne = fullInput.substr(quotationIndexOne + 1, (quotationIndexTwo - quotationIndexOne - 1));
            inputParameterTwo = fullInput.substr(quotationIndexTwo + 2, fullInput.size() - 1);
        }
    }

    // Helper function that checks if a string is a number (only contains digits).
    bool isValidNumber(string input) {
        // If something other than a number is found while traversing the input, return false.
        for (int i = 0; i < input.size(); i++) {
            if (!isdigit(input[i])) {
                return false;
            }
        }
        return true;
    }



    /// Required Functions:
    /// Functions specifically stated to be required within the project's requirements.
    // Helper function used to properly set the value of root when calling insert and prevent an infinite loop.
    bool insert (string name, string idInput) {
        // Boolean used in return statement outputting whether the function was successful or not - used in unit testing.
        bool matchFound = true;
        // If the name and ID are valid, call insertFunction.
        if (isValidName(name) && isValidId(idInput) && !name.empty()) {
            int id = stoi(idInput);
            root = insertFunction(root, name, id, matchFound);
        }
            // Otherwise, output "unsuccessful" and return false.
        else {
            matchFound = false;
            cout << "unsuccessful" << endl;
        }
        return matchFound;
    }
    // Method to construct the tree, adding new nodes.
    Node* insertFunction(Node* node, string name, int id, bool& matchFound) {
        // Input and the new node when the correct space is found, increase the number of total nodes, and output that insert was successful.
        if (node == nullptr) {
            Node *tempNode = new Node(name, id);
            numNodes++;
            cout << "successful" << endl;
            return tempNode;
        }
        // Traverse through the existing tree until the correct location for the node is found.
        if (id < node->idNum) {
            node->left = insertFunction(node->left, name, id, matchFound);
        }
        else if (id > node->idNum) {
            node->right = insertFunction(node->right, name, id, matchFound);
        }
        else {
            // A backup "unsuccessful" output for if a repeated ID is inputted. Also has the insert function return false.
            matchFound = false;
            cout << "unsuccessful" << endl;
            return node;
        }

        // Set height for the traversed nodes.
        node->height = findHeight(node);

        // Balance the tree based on the results of findBalance for each node.
        int balance = findBalance(node);

        // Make sure the node on the left exists to prevent trying to access an ID number that does not exist.
        if (node->left != nullptr) {
            // Left-Left case:
            if (balance > 1 && node->left->idNum > id) {
                return rotateRight(node);
            }
            // Left-Right case:
            if (balance > 1 && node->left->idNum < id) {
                return rotateLeftRight(node);
            }
        }
        // Make sure the node on the right exists to prevent trying to access an ID number that does not exist.
        if (node->right != nullptr) {
            // Right-Right case:
            if (balance < -1 && node->right->idNum < id) {
                return rotateLeft(node);
            }
            // Right-Left case:
            if (node->left != nullptr) {
                if (balance < -1 && node->right->idNum > id) {
                    return rotateRightLeft(node);
                }
            }
        }
        return node;
    }

    // Helper function call for remove without needing to call a Node pointer in main.
    bool remove(int id) {
        // Call the removeFunction, once it is completed output whether the removal worked or not.
        bool matchFound = false;
        root = removeFunction(root, id, matchFound);
        if (matchFound) {
            cout << "successful" << endl;
        }
        else {
            cout << "unsuccessful" << endl;
        }
        return matchFound;
    }
    // Method used to delete nodes from the tree.
    Node* removeFunction(Node* node, int id, bool& matchFound) {
        // Check to see if a tree exists.
        if (node == nullptr) {
            return node;
        }
        // Iterate through loop - go left if need a smaller ID, go right if need a bigger ID
        if (node->idNum > id) {
            node->left = removeFunction(node->left, id, matchFound);
        }
        else if (node->idNum < id) {
            node->right = removeFunction(node->right, id, matchFound);
        }
        else {
            matchFound = true;
            numNodes--;

            // If no children, remove the inputted node.
            if (node->left == nullptr && node->right == nullptr) {
                return nullptr;
            }
                // If only one child on left, replace the inputted node with its left child.
            else if (node->left != nullptr && node->right == nullptr) {
                Node* tempNode = node->left;
                delete(node);
                node = tempNode;
            }
                // If only one child on right, replace the inputted node with its right child.
            else if (node->left == nullptr && node->right != nullptr) {
                Node* tempNode = node->right;
                delete(node);
                node = tempNode;
            }
                // If two children...
            else {
                // Find the inorder successor, set node to match its values, then remove the successor from the tree.
                Node* inorderSuccessor = findInorderSuccessor(node);
                node->idNum = inorderSuccessor->idNum;
                node->subName = inorderSuccessor->subName;
                node->right = removeFunction(node->right, inorderSuccessor->idNum, matchFound);
                numNodes++;
            }
        }
        return node;
    }

    // Helper function allowing a call of search without requiring the use of a node in main.
    bool search(int id) {
        // Call the searchFunction, once it is completed output "unsuccessful" if the search failed.
        bool matchFound = false;
        searchFunction(root, id, matchFound);
        if (!matchFound) {
            cout << "unsuccessful" << endl;
        }
        return matchFound;
    }
    // Method used to search for a name matching an inputted ID
    void searchFunction(Node* node, int id, bool& matchFound) {
        // Check to see if a tree exists.
        if (node != nullptr) {
            // Move based on preorder traversal, if the sought ID is found return the node's name.
            if (node->idNum == id) {
                matchFound = true;
                cout << node->subName << endl;
                return;
            }
                // Move left if need a smaller ID, right if need a bigger ID.
            else if (node->idNum > id) {
                searchFunction(node->left, id, matchFound);
            }
            else {
                searchFunction(node->right, id, matchFound);
            }
        }
    }

    // Helper function allowing a call of search without requiring the use of a node in main.
    bool search(string name) {
        // Call the searchFunction, once it is completed output "unsuccessful" if the search failed.
        bool matchFound = false;
        searchFunction(root, name, matchFound);
        if (!matchFound) {
            cout << "unsuccessful" << endl;
        }
        return matchFound;
    }
    // Method used to search for any ID numbers matching an inputted name.
    void searchFunction(Node* node, string name, bool& matchFound) {
        // Check to see if a tree exists.
        if (node != nullptr) {
            // Remove quotation marks from the inputted name if necessary using the parseName helper function.
            string parsedName = parseName(name);
            // Move based on preorder traversal, if the sought name is found return any ID's matching the name.
            if (node->subName == parsedName) {
                cout << printLeadingZeros(node->idNum) << node->idNum << endl;
                matchFound = true;
            }
            searchFunction(node->left, parsedName, matchFound);
            searchFunction(node->right, parsedName, matchFound);
        }
    }

    // Function used to call for an inorder traversal and print the results of the main function below.
    // Outputs a boolean - used for unit testing.
    bool printInorder() {
        // Vector holding results of inorder traversal performed in printInorderFunction
        vector<string> inorderResults;
        // Call the main function
        printInorderFunction(root, inorderResults);

        // Separate all results of inorder traversal with commas except for the final output which calls a new line.
        if (inorderResults.size() == numNodes && root != nullptr) {
            for (int i = 0; i < inorderResults.size() - 1; i++) {
                cout << inorderResults[i] << ", ";
            }
            cout << inorderResults[inorderResults.size() - 1] << endl;
            return true;
        }
            // Print unsuccessful if printInorderFunction fails for any reason (nonexistent tree).
        else {
            cout << "unsuccessful" << endl;
            return false;
        }
    }
    // Function used to call for an inorder traversal and print the results of the main function below.
    // Outputs a vector of strings - used for unit testing.
    vector<string> printInorder(vector<string> inorderResults) {
        // Call the main function
        printInorderFunction(root, inorderResults);

        // Separate all results of inorder traversal with commas except for the final output which calls a new line.
        if (inorderResults.size() == numNodes && root != nullptr) {
            for (int i = 0; i < inorderResults.size() - 1; i++) {
                cout << inorderResults[i] << ", ";
            }
            cout << inorderResults[inorderResults.size() - 1] << endl;
        }
            // Print unsuccessful if printInorderFunction fails for any reason (nonexistent tree).
        else {
            cout << "unsuccessful" << endl;
        }
        return inorderResults;
    }
    // Function performing inorder traversal.
    void printInorderFunction(Node* node, vector<string>& inorderResults) {
        // Check to see if a tree exists then perform inorder traversal. Add results to vector called in previous function.
        if (node != nullptr) {
            printInorderFunction(node->left, inorderResults);
            inorderResults.push_back(node->subName);
            printInorderFunction(node->right, inorderResults);
        }
    }

    // Function used to call for a preorder traversal and print the results of the main function below.
    // Returns a boolean - used for unit testing.
    bool printPreorder() {
        // Vector holding results of preorder traversal performed in printPreorderFunction
        vector<string> preorderResults;
        // Call the main function
        printPreorderFunction(root, preorderResults);

        // Separate all results of preorder traversal with commas except for the final output which calls a new line.
        if (preorderResults.size() == numNodes && root != nullptr) {
            for (int i = 0; i < preorderResults.size() - 1; i++) {
                cout << preorderResults[i] << ", ";
            }
            cout << preorderResults[preorderResults.size() - 1] << endl;
            return true;
        }
            // Print unsuccessful if printPreorderFunction fails for any reason (nonexistent tree).
        else {
            cout << "unsuccessful" << endl;
            return false;
        }
    }
    // Function used to call for an preorder traversal and print the results of the main function below.
    // Outputs a vector of strings - used for unit testing.
    vector<string> printPreorder(vector<string> preorderResults) {
        // Call the main function
        printPreorderFunction(root, preorderResults);

        // Separate all results of preorder traversal with commas except for the final output which calls a new line.
        if (preorderResults.size() == numNodes && root != nullptr) {
            for (int i = 0; i < preorderResults.size() - 1; i++) {
                cout << preorderResults[i] << ", ";
            }
            cout << preorderResults[preorderResults.size() - 1] << endl;
        }
            // Print unsuccessful if printPreorderFunction fails for any reason (nonexistent tree).
        else {
            cout << "unsuccessful" << endl;
        }
        return preorderResults;
    }
    // Function performing preorder traversal.
    void printPreorderFunction(Node* node, vector<string>& preorderResults) {
        // Check to see if a tree exists then perform preorder traversal. Add results to vector called in previous function.
        if (node != nullptr) {
            preorderResults.push_back(node->subName);
            printPreorderFunction(node->left, preorderResults);
            printPreorderFunction(node->right, preorderResults);
        }
    }

    // Function used to call for a postorder traversal and print the results of the main function below.
    // Outputs a boolean - used for unit testing.
    bool printPostorder() {
        // Vector holding results of postorder traversal performed in findInorder
        vector<string> postorderResults;
        // Call the main function
        printPostorderFunction(root, postorderResults);

        // Separate all results of postorder traversal with commas except for the final output which calls a new line.
        if (postorderResults.size() == numNodes && root != nullptr) {
            for (int i = 0; i < postorderResults.size() - 1; i++) {
                cout << postorderResults[i] << ", ";
            }
            cout << postorderResults[postorderResults.size() - 1] << endl;
            return true;
        }
            // Print unsuccessful if printPostorderFunction fails for any reason (nonexistent tree).
        else {
            cout << "unsuccessful" << endl;
            return false;
        }
    }
    // Function used to call for an inorder traversal and print the results of the main function below.
    // Outputs a vector of strings - used for unit testing.
    vector<string> printPostorder(vector<string> postorderResults) {
        // Call the main function
        printPostorderFunction(root, postorderResults);

        // Separate all results of postorder traversal with commas except for the final output which calls a new line.
        if (postorderResults.size() == numNodes && root != nullptr) {
            for (int i = 0; i < postorderResults.size() - 1; i++) {
                cout << postorderResults[i] << ", ";
            }
            cout << postorderResults[postorderResults.size() - 1] << endl;
        }
            // Print unsuccessful if printPostorderFunction fails for any reason (nonexistent tree).
        else {
            cout << "unsuccessful" << endl;
        }
        return postorderResults;
    }
    // Function performing postorder traversal.
    void printPostorderFunction(Node* node, vector<string>& postorderResults) {
        // Check to see if a tree exists.
        if (node != nullptr) {
            printPostorderFunction(node->left, postorderResults);
            printPostorderFunction(node->right, postorderResults);
            postorderResults.push_back(node->subName);
        }
    }

    // Support function used to call the main function without needing to call a node pointer in main.
    // Also outputs the result of the main function.
    int printLevelCount() {
        int numLevels = 0;
        printLevelCountFunction(root, numLevels);
        cout << numLevels << endl;
        return numLevels;
    }
    // Function used to determine the number of lines in the tree.
    void printLevelCountFunction(Node* node, int& numLevels) {
        if (node != nullptr) {
            // Uses a queue to maneuver through the given tree and iterate per every level.
            // Also includes a dummy pointer used to show when a level ends.
            Node dummyNode("dummy", -1); // Node used to determine when level ends
            Node* dummyPtr = &dummyNode; // Points to dummyNode
            queue<Node*> levelQueue;
            // Last dummy boolean used to prevent an infinite loop for the queue.
            bool lastDummy = false;

            // Add both the inputted node and the dummy pointer to the queue.
            levelQueue.push(node);
            levelQueue.push(dummyPtr);
            // While loop to move to necessary level and add members of that level to sum.
            while (!levelQueue.empty()) {
                Node* currentNode = levelQueue.front();
                levelQueue.pop();

                // If program finds a dummy node, all nodes for next line added to queue and numLevels++. Adds new dummy node onto end.
                if (currentNode->idNum == -1 && !lastDummy) {
                    numLevels++;
                    levelQueue.push(dummyPtr);
                    lastDummy = true;
                    continue;
                }
                else {
                    lastDummy = false;
                }
                // Add any nodes to the left and right of current node onto the queue
                if (currentNode->left != nullptr) {
                    levelQueue.push(currentNode->left);
                }
                if (currentNode->right != nullptr) {
                    levelQueue.push(currentNode->right);
                }
            }
        }
    }

    // Helper function used to call for removeInorder without needing to call a node pointer in main.
    // Also outputs if function unsuccessful by comparing number of nodes when called to number of nodes after called.
    bool removeInorder(int n) {
        // Set currentIndex (which must reset every time function is called)
        // Set numNodesStart (which records the number of nodes when the function is called to check if the number changes later on).
        int currentIndex = 0;
        int numNodesStart = numNodes;
        // Call main function
        removeInorderFunction(root, n, currentIndex);
        if (numNodesStart == numNodes) {
            cout << "unsuccessful" << endl;
            return false;
        }
        else {
            return true;
        }
    }
    // Method used to delete nodes from the tree.
    void removeInorderFunction(Node* node, int n, int& currentIndex) {
        // Check to see if a tree exists.
        if (node == nullptr) {
            return;
        }
        // Iterate with inorder traversal while keeping track of the number of nodes passed.
        // Goes left if needs a smaller ID, goes right if needs a bigger ID
        if (currentIndex <= n) {
            removeInorderFunction(node->left, n, currentIndex);
            if (n == currentIndex) {
                remove(node->idNum);
            }
            currentIndex++;
            removeInorderFunction(node->right, n, currentIndex);
        }
    }
};



/// Main Function:
int main() {
    // Call an AVL tree to use in main.
    MyAVLTree inputTree;

    bool correctFirstPrompt = false;
    string numCommandsInput = "";

    // While loop used to require a valid integer before proceeding.
    while (!correctFirstPrompt) {
        cin >> numCommandsInput;
        for (int i = 0; i < numCommandsInput.size(); i++) {
            if (isdigit(numCommandsInput[i])) {
                correctFirstPrompt = true;
            }
            else {
                correctFirstPrompt = false;
                cout << "unsuccessful" << endl;
                break;
            }
        }
    }
    // Converts user input into a usable integer representing how many user inputs will be taken.
    int numCommands = stoi(numCommandsInput);

    for (int i = 0; i <= numCommands; i++) {
        // For each new line of user input, call getInputs to set new values for the function name and parameter variables.
        string fullInput = "";
        string inputFunction = "";
        string inputParameterOne = "";
        string inputParameterTwo = "";
        getline(cin, fullInput);
        inputTree.getInputs(fullInput, inputFunction, inputParameterOne, inputParameterTwo);

        // Call the insert function.
        if (inputFunction == "insert") {
            inputTree.insert(inputParameterOne, inputParameterTwo);
        }
            // Call the remove function.
        else if (inputFunction == "remove" && inputTree.isValidNumber(inputParameterOne)) {
            inputTree.remove(stoi(inputParameterOne));
        }
            // Call the search function - if the first parameter is a name, search for that name. If it is an ID, search for the ID.
        else if (inputFunction == "search") {
            if (inputTree.isValidNumber(inputParameterOne)) {
                inputTree.search(stoi(inputParameterOne));
            }
            else {
                inputTree.search(inputParameterOne);
            }
        }
            // Call for preorder traversal.
        else if (inputFunction == "printPreorder") {
            inputTree.printPreorder();
        }
            // Call for inorder traversal.
        else if (inputFunction == "printInorder") {
            inputTree.printInorder();
        }
            // Call for postorder traversal.
        else if (inputFunction == "printPostorder") {
            inputTree.printPostorder();
        }
            // Call the printLevelCount function.
        else if (inputFunction == "printLevelCount") {
            inputTree.printLevelCount();
        }
            // Call the removeInorder function.
        else if (inputFunction == "removeInorder" && inputTree.isValidNumber(inputParameterOne)) {
            inputTree.removeInorder(stoi(inputParameterOne));
        }
            // If none of the set functions are called, output that the process was unsuccessful.
        else {
            // The first iteration of the for loop will always reach this else statement, so only print unsuccessful if at any iteration other than the first.
            if (i != 0) {
                cout << "unsuccessful" << endl;
            }
        }
    }
    return 0;
}