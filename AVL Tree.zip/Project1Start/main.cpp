//#define CATCH_CONFIG_MAIN
//#include "catch.hpp"
#include <iostream>
#include <iomanip>
#include <queue>
#include <string>
#include <vector>
#include <unordered_map>
using namespace std;

/* Note: 
	1. You will have to comment main() when unit testing your code because catch uses its own main().
	2. You will submit this main.cpp file and any header files you have on Gradescope. 
*/

class AVL {
    public:
    class Node {
        public:
        string subName;
        int idNum;
        int height;
        Node *left;
        Node *right;
        Node(string x, int y): subName(x), idNum(y), height(0), left(nullptr), right(nullptr) {}
    };
    Node* root = nullptr;
    int numNodes = 0;

    /// Helper Functions:
    // Helper function to split a getline string into parts.
    void getInputs(string fullInput, string& inputFunction, string& inputParameterOne, string& inputParameterTwo) {
        int numSpaces = 0;
        for (int i = 0; i < fullInput.size(); i++) {
            if (fullInput[i] == ' ') {
                numSpaces++;
            }
        }

        // If there are no spaces, only a function is called - set that to inputFunction
        if (numSpaces == 0) {
            inputFunction = fullInput;
        }
        // If there is one space, there is a called function with one parameter
        else if (numSpaces == 1) {
            inputFunction = fullInput.substr(0, fullInput.find(' '));
            inputParameterOne = fullInput.substr( fullInput.find(' ') + 1, fullInput.size());
            // Remove quotation marks from names if necessary
            if (inputParameterOne.find('"') != string::npos) {
                inputParameterOne = parseName(inputParameterOne);
            }
        }
        // If there are two spaces, there is a called function with two parameters
        else if (numSpaces == 2) {
            int inputNum = 1;
            for (int i = 0; i < fullInput.size(); i++) {
                if (fullInput[i] != ' ') {
                    if (inputNum == 1) {
                        inputFunction.push_back(fullInput[i]);
                    } else if (inputNum == 2) {
                        inputParameterOne.push_back(fullInput[i]);
                    } else if (inputNum == 3) {
                        inputParameterTwo.push_back(fullInput[i]);
                    } else {
                        break;
                    }
                } else {
                    inputNum++;
                    continue;
                }
            }
            // Remove quotation marks from names if necessary
            if (inputParameterOne.find('"') != string::npos) {
                inputParameterOne = parseName(inputParameterOne);
            }
        }
    }
    // Helper function that removes the quotation marks from submitted names
    string parseName(string name) {
        string parsedName;
        if (name.size() > 2 && name[0] == '"' && name[name.size() - 1] == '"') {
            parsedName = name.substr(1, name.size() - 2);
            return parsedName;
        }
        else {
            return "";
        }
    }
    // Helper function that checks if a string is a valid number
    bool isValidNumber(string input) {
        for (int i = 0; i < input.size(); i++) {
            if (!isdigit(input[i])) {
                return false;
            }
        }
        return true;
    }
    // Helper function to see if an inputted name is allowed.
    bool isValidName(string name) {
        for (int i = 0; i < name.size(); i++) {
            if ((!isalpha(name[i]) && name[i] != ' ')) {
                return false;
            }
        }
        return true;
    }
    // Helper function to see if an inputted ID number is allowed.
    bool isValidId(string id) {
        if (id.size() <= 8 && isValidNumber(id)) {
            return true;
        }
        else {
            return false;
        }
    }
    // Helper function which helps add leading zeroes for cases when an inputted ID number is less than 10000000.
    string printLeadingZeros(int idNum) {
        // Needs seven leading zeros
        if (idNum < 10) {
            return "0000000";
        }
        // Needs six leading zeros
        else if (idNum < 100) {
            return "000000";
        }
        // Needs five leading zeros
        else if (idNum < 1000) {
            return "00000";
        }
        // Needs four leading zeros
        else if (idNum < 10000) {
            return "0000";
        }
        // Needs three leading zeros
        else if (idNum < 100000) {
            return "000";
        }
        // Needs two leading zeros
        else if (idNum < 1000000) {
            return "00";
        }
        // Needs one leading zero
        else if (idNum < 10000000) {
            return "0";
        }
        // Needs no leading zeros
        else if (idNum < 100000000) {
            return "";
        }
    }
    // Helper function to get the inorder successor
    Node* findInorderSuccessor(Node* node) {
        Node* currentNode = node;
        currentNode = currentNode->right;
        while (currentNode->left != nullptr) {
            currentNode = currentNode->left;
        }
        return currentNode;
    }
    // Helper function to find the height of a node
    int findHeight(Node* node) {
        if (node == nullptr) {
            return 0;
        }
        else {
            int leftHeight = findHeight(node->left);
            int rightHeight = findHeight(node->left);
            if (leftHeight > rightHeight) {
                return leftHeight + 1;
            }
            else {
                return rightHeight + 1;
            }
        }
    }
    // Helper function to find the balance for a node.
    int findBalance(Node* node) {
        if (node == nullptr) {
            return 0;
        }
        else {
            int leftSubtree = findHeight(node->left);
            int rightSubtree = findHeight(node->right);
            int balance = leftSubtree - rightSubtree;
            return balance;
        }
    }
    // Helper function for left rotate
    Node* rotateLeft(Node *node)
    {
        Node* nodeB = node->right;
        Node* nodeX = nodeB->left;
        nodeB->left = node;
        node->right = nodeX;
        return nodeB;
    }
    // Helper function for right rotate
    Node* rotateRight(Node *node)
    {
        Node* nodeB = node->left;
        Node* nodeY = nodeB->right;
        nodeB->right = node;
        node->left = nodeY;
        return nodeB;
    }
    // Helper function for a left-right rotation
    Node* rotateLeftRight(Node *node)
    {
        node->left = rotateLeft(node->left);
        return rotateRight(node);
    }
    // Helper function for a right-left rotation
    Node* rotateRightLeft(Node *node)
    {
        node->right = rotateRight(node->right);
        return rotateLeft(node);
    }
    // Function used for testing - outputs if a tree is not balanced
    void isBalancedTree() {
        isBalancedTreeFunction(root);
    }
    void isBalancedTreeFunction(Node* node) {
        if (node == nullptr) {
            return;
        }
        isBalancedTreeFunction(node->left);
        int balance = findBalance(node);
        if (balance > 1 || balance < -1) {
            cout << node->subName << " is unbalanced - height is " << balance << endl;
        }
        isBalancedTreeFunction(node->right);
    }

    /// Required Functions:
    // Helper function to insert to properly set the value of root and prevent an infinite loop.
    void insert (string name, string idInput) {
        if (isValidName(name) && isValidId(idInput) && !name.empty()) {
            int id = stoi(idInput);
            root = insertFunction(root, name, id);
        }
        else {
            cout << "unsuccessful" << endl;
        }
    }
    // Method to construct the tree, adding new nodes.
    Node* insertFunction(Node* node, string name, int id) {
        if (node == nullptr) {
            numNodes++;
            Node *tempNode = new Node(name, id);
            return tempNode;
        }
        if (id < node->idNum) {
            node->left = insertFunction(node->left, name, id);
        }
        else if (id > node->idNum) {
            node->right = insertFunction(node->right, name, id);
        }
        else {
            cout << "unsuccessful" << endl;
            return node;
        }
        // Set height
        node->height = findHeight(node);
        // Balancing
        int balance = findBalance(node);
        if (balance > 1 && id < node->left->idNum) {
            return rotateRight(node);
        }
        if (balance > 1 && id > node->left->idNum) {
            return rotateLeftRight(node);
        }
        if (balance < -1 && id < node->left->idNum) {
            return rotateLeft(node);
        }
        if (balance < -1 && id > node->left->idNum) {
            return rotateRightLeft(node);
        }
        return node;
    }
    // Helper function call for remove without needing to call a Node* in main.
    void remove(int id) {
        bool matchFound = false;
        root = removeFunction(root, id, matchFound);
        if (!matchFound) {
            cout << "unsuccessful" << endl;
        }
    }
    // Method used to delete nodes from the tree.
    Node* removeFunction(Node* node, int id, bool& matchFound) {
        // Check to see if a tree exists.
        if (node == nullptr) {
            return node;
        }
        // Iterate through loop - go left if need a smaller ID, go right if need a bigger ID
        if (node->idNum > id) {
            node->left = removeFunction(node->left, id, matchFound);
        }
        else if (node->idNum < id) {
            node->right = removeFunction(node->right, id, matchFound);
        }
        else {
            numNodes--;
            matchFound = true;
            cout << "successful" << endl;

            // If no children...
            if (node->left == nullptr && node->right == nullptr) {
                return nullptr;
            }
            // If only one child on left
            else if (node->left != nullptr && node->right == nullptr) {
                Node* tempNode = node->left;
                delete(node);
                node = tempNode;
            }
            // If only one child on right
            else if (node->left == nullptr && node->right != nullptr) {
                Node* tempNode = node->right;
                delete(node);
                node = tempNode;
            }
            // If two children
            else {
                Node* inorderSuccessor = findInorderSuccessor(node);
                node->idNum = inorderSuccessor->idNum;
                node->subName = inorderSuccessor->subName;
                node->right = removeFunction(node->right, inorderSuccessor->idNum, matchFound);
                numNodes++;
            }
        }
        return node;
    }
    // Helper function allowing a call of search without requiring the use of a node in main. Also used to print unsuccessful for faulty searches.
    void search(int id) {
        bool matchFound = false;
        searchFunction(root, id, matchFound);
        if (!matchFound) {
            cout << "unsuccessful" << endl;
        }
    }
    void searchFunction(Node* node, int id, bool& matchFound) {
        // Check to see if a tree exists.
        if (node != nullptr) {
            if (node->idNum == id) {
                matchFound = true;
                cout << node->subName << endl;
                return;
            }
            searchFunction(node->left, id, matchFound);
            searchFunction(node->right, id, matchFound);
        }
    }
    // Helper function allowing a call of search without requiring the use of a node in main. Also used to print unsuccessful for faulty searches.
    void search(string name) {
        bool matchFound = false;
        searchFunction(root, name, matchFound);
        if (!matchFound) {
            cout << "unsuccessful" << endl;
        }
    }
    void searchFunction(Node* node, string name, bool& matchFound) {
        // Vector to hold results of traversal.
        vector<Node*> searchResults;

        // Check to see if a tree exists.
        if (node != nullptr) {
            if (node->subName == name) {
                cout << printLeadingZeros(node->idNum) << node->idNum << endl;
                matchFound = true;
                return;
            }
            searchFunction(node->left, name, matchFound);
            searchFunction(node->right, name, matchFound);
        }
    }
    void printPreorder() {
        vector<string> preorderResults;
        findPreorder(root, preorderResults);
        if (preorderResults.size() == numNodes && root != nullptr) {
            for (int i = 0; i < preorderResults.size() - 1; i++) {
                cout << preorderResults[i] << ", ";
            }
            cout << preorderResults[preorderResults.size() - 1] << endl;
            return;
        }
        else {
            cout << "unsuccessful" << endl;
        }
    }
    void findPreorder(Node* node, vector<string>& preorderResults) {
        // Check to see if a tree exists.
        if (node != nullptr) {
            preorderResults.push_back(node->subName);
            findPreorder(node->left, preorderResults);
            findPreorder(node->right, preorderResults);
        }
    }
    void printInorder() {
        vector<string> inorderResults;
        findInorder(root, inorderResults);
        if (inorderResults.size() == numNodes && root != nullptr) {
            for (int i = 0; i < inorderResults.size() - 1; i++) {
                cout << inorderResults[i] << ", ";
            }
            cout << inorderResults[inorderResults.size() - 1] << endl;
            return;
        }
        else {
            cout << "unsuccessful" << endl;
        }
    }
    void findInorder(Node* node, vector<string>& inorderResults) {
        // Check to see if a tree exists.
        if (node != nullptr) {
            findInorder(node->left, inorderResults);
            inorderResults.push_back(node->subName);
            findInorder(node->right, inorderResults);
        }
    }
    void printPostorder() {
        vector<string> postorderResults;
        findPostorder(root, postorderResults);
        if (postorderResults.size() == numNodes && root != nullptr) {
            for (int i = 0; i < postorderResults.size() - 1; i++) {
                cout << postorderResults[i] << ", ";
            }
            cout << postorderResults[postorderResults.size() - 1] << endl;
            return;
        }
        else {
            cout << "unsuccessful" << endl;
        }
    }
    void findPostorder(Node* node, vector<string>& postorderResults) {
        // Check to see if a tree exists.
        if (node != nullptr) {
            findPostorder(node->left, postorderResults);
            findPostorder(node->right, postorderResults);
            postorderResults.push_back(node->subName);
        }
    }
    void printLevelCount() {
        int numLevels = 0; // Start at one since root dummyPtr already in place.
        printLevelCountFunction(root, numLevels);
        cout << numLevels << endl;
    }
    void printLevelCountFunction(Node* node, int& numLevels) {
        if (node != nullptr) {
            // Uses a queue to maneuver through the given tree and iterate per every level.
            // Also includes a dummy pointer used to show when a level ends.
            Node dummyNode("dummy", -1); // Node used to determine when level ends
            Node* dummyPtr = &dummyNode; // Points to dummyNode
            queue<Node*> levelQueue;
            bool lastDummy = false;

            levelQueue.push(node);
            levelQueue.push(dummyPtr);
            // While loop to move to necessary level and add members of that level to sum.
            while (!levelQueue.empty()) {
                Node* currentNode = levelQueue.front();
                levelQueue.pop();

                // If program finds a dummy node, all nodes for next line added to queue and numLevels++. Adds new dummy node onto end.
                if (currentNode->idNum == -1 && !lastDummy) {
                    numLevels++;
                    levelQueue.push(dummyPtr);
                    lastDummy = true;
                    continue;
                }
                else {
                    lastDummy = false;
                }
                // Add any nodes to the left and right of current node onto the queue
                if (currentNode->left != nullptr) {
                    levelQueue.push(currentNode->left);
                }
                if (currentNode->right != nullptr) {
                    levelQueue.push(currentNode->right);
                }
            }
        }
    }
    // Helper function call for remove without needing to call a Node* in main.
    void removeInorder(int n) {
        int currentIndex = 0;
        int numNodesStart = numNodes;
        removeInorderFunction(root, n, currentIndex);
        if (numNodesStart == numNodes) {
            cout << "unsuccessful" << endl;
        }
    }
    // Method used to delete nodes from the tree.
    void removeInorderFunction(Node* node, int n, int& currentIndex) {
        // Check to see if a tree exists.
        if (node == nullptr) {
            return;
        }
        // Iterate through loop - go left if need a smaller ID, go right if need a bigger ID
        if (currentIndex <= n) {
            removeInorderFunction(node->left, n, currentIndex);
            if (n == currentIndex) {
                remove(node->idNum);
            }
            currentIndex++;
            removeInorderFunction(node->right, n, currentIndex);
        }
    }
};

int main() {
    AVL inputTree;

    bool correctFirstPrompt = false;
    string numCommandsInput = "";

    while (!correctFirstPrompt) {
        cin >> numCommandsInput;
        for (int i = 0; i < numCommandsInput.size(); i++) {
            if (isdigit(numCommandsInput[i])) {
                correctFirstPrompt = true;
            }
            else {
                correctFirstPrompt = false;
                break;
            }
        }
    }
    int numCommands = stoi(numCommandsInput);

    for (int i = 0; i <= numCommands; i++) {
        string fullInput = "";
        string inputFunction = "";
        string inputParameterOne = "";
        string inputParameterTwo = "";
        getline(cin, fullInput);
        inputTree.getInputs(fullInput, inputFunction, inputParameterOne, inputParameterTwo);

        if (inputFunction == "insert") {
            inputTree.insert(inputParameterOne, inputParameterTwo);
        }
        else if (inputFunction == "remove" && inputTree.isValidNumber(inputParameterOne)) {
            inputTree.remove(stoi(inputParameterOne));
        } //
        else if (inputFunction == "search") {
            if (inputTree.isValidNumber(inputParameterOne)) {
                inputTree.search(stoi(inputParameterOne));
            }
            else {
                inputTree.search(inputParameterOne);
            }
        }
        else if (inputFunction == "printPreorder") {
            inputTree.printPreorder();
        }
        else if (inputFunction == "printInorder") {
            inputTree.printInorder();
        }
        else if (inputFunction == "printPostorder") {
            inputTree.printPostorder();
        }
        else if (inputFunction == "printLevelCount") {
            inputTree.printLevelCount();
        }
        else if (inputFunction == "removeInorder" && inputTree.isValidNumber(inputParameterOne)) {
            inputTree.removeInorder(stoi(inputParameterOne));
        } //
        else {
            if (i != 0) {
                cout << "unsuccessful" << endl;
            }
        }
    }
    return 0;
}

/// Test Cases:
/*  AVL inputTree;

    bool correctFirstPrompt = false;
    string numCommandsInput = "";

    while (!correctFirstPrompt) {
        cin >> numCommandsInput;
        for (int i = 0; i < numCommandsInput.size(); i++) {
            if (isdigit(numCommandsInput[i])) {
                correctFirstPrompt = true;
            }
            else {
                correctFirstPrompt = false;
                break;
            }
        }
    }
    int numCommands = stoi(numCommandsInput);

    for (int i = 0; i <= numCommands; i++) {
        string fullInput = "";
        string inputFunction = "";
        string inputParameterOne = "";
        string inputParameterTwo = "";
        getline(cin, fullInput);
        inputTree.getInputs(fullInput, inputFunction, inputParameterOne, inputParameterTwo);

        if (inputFunction == "insert") {
            inputTree.insert(inputParameterOne, inputParameterTwo);
        }
        else if (inputFunction == "remove" && inputTree.isValidNumber(inputParameterOne)) {
            inputTree.remove(stoi(inputParameterOne));
        }
        else if (inputFunction == "search") {
            if (inputTree.isValidNumber(inputParameterOne)) {
                inputTree.search(stoi(inputParameterOne));
            }
            else {
                inputTree.search(inputParameterOne);
            }
        }
        else if (inputFunction == "printPreorder") {
            inputTree.printPreorder();
        }
        else if (inputFunction == "printInorder") {
            inputTree.printInorder();
        }
        else if (inputFunction == "printPostorder") {
            inputTree.printPostorder();
        }
        else if (inputFunction == "printLevelCount") {
            inputTree.printLevelCount();
        }
        else if (inputFunction == "removeInorder" && inputTree.isValidNumber(inputParameterOne)) {
            inputTree.removeInorder(stoi(inputParameterOne));
        }
        else {
            if (i != 0) {
                cout << "unsuccessful" << endl;
            }
        }
    }
    return 0;
 *
 */
/*AVL inputTree;

    string name = " ";
    int idNumber = 10000000;
    string letters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    int j = 0;

    for (int i = 0; i <= 300; i++) {
        name.pop_back();
        name.push_back(letters[j]);
        inputTree.insert(name, idNumber);
        idNumber++;
        j++;
        if (j == 52) {
            name.push_back(' ');
            j = 0;
        }
    }
    inputTree.remove(10000001);
    inputTree.remove(10000299);
    inputTree.search(10000201);
    inputTree.search("Za");
    inputTree.removeInorder(3);
    inputTree.printPreorder();
    inputTree.printInorder();
    inputTree.printPostorder();
    inputTree.printLevelCount();
    inputTree.removeInorder(1);
    inputTree.insert("rebalance", 99999999);
    inputTree.removeInorder(2);
    inputTree.printInorder();
    return 0;
 *
 */
/*
 * AVL inputTree;
    inputTree.printPreorder();
    inputTree.insert("InputOne", 20000000);
    inputTree.insert("InputTwo", 10000000);
    inputTree.insert("InputThree", 40000000);
    inputTree.insert("InputFour", 50000000);
    inputTree.insert("InputFive", 60000000);
    inputTree.printPreorder();
    inputTree.printInorder();
    inputTree.printPostorder();
    inputTree.search("Nonexistent");
    inputTree.search("InputThree");
    inputTree.search(60000000);
    inputTree.printLevelCount();
    inputTree.isBalancedTree();
    inputTree.remove(20000000);
    inputTree.printInorder();
    inputTree.removeInorder(2);
    inputTree.printPreorder();
 */

/*TEST_CASE("BST Insert", "[flag]") {
    AVL inputTree;
    inputTree.insert(inputTree.root, "Jim", 42004200);
}*/
/*// Helper function that finds the size of the tree. Make sure works later
    int findTreeSize(Node* node) {
        if (node == nullptr) {
            return 0;
        }
        else {
            // Uses a queue to maneuver through the given tree and iterate per every level.
            queue<Node *> sizeQueue;
            sizeQueue.push(node);
            int treeSize = 1;
            // While loop to move to necessary level and add members of that level to sum.
            while (!sizeQueue.empty()) {
                Node *currentNode = sizeQueue.front();
                sizeQueue.pop();

                // Add any nodes to the left and right of current node onto the queue
                if (currentNode->left != nullptr) {
                    sizeQueue.push(currentNode->left);
                    treeSize++;
                }
                if (currentNode->right != nullptr) {
                    sizeQueue.push(currentNode->right);
                    treeSize++;
                }
            }
            return treeSize;
        }
    }
 */
/* Weird broken case:
 * Consequence of the IDs somehow. Don't know how. Run and check error. Maybe has to do with the root variable?
 * If it is the root causing this could have a root and a like head variable so head can be saved idk man i just work here.
int main() {
    AVL inputTree;
    inputTree.insert("InputOne", 42004200);
    inputTree.insert("InputTwo", 58483848);
    inputTree.insert("InputThree", 58433848);
    inputTree.insert("InputFour", 58645384);
    inputTree.insert("InputFive", 58476848);
    inputTree.printPreorder();
    return 0;
}*/
/*            // TODO: Need to return new root after node deleted to account for cases where the root changes. That is the (part of) the point of splitting remove function into two.
            // TODO: (Other purpose of remove() and removeFunction() divide is so will not need to call a Node* in main).
            // TODO: At the moment, returns node, which won't work because in cases like if there is one child, it returns the deleted node's child, not the root. Placeholder.
            // TODO: Question is, how can I make sure remove outputs the root and not some random node? Do I even need to?
 *     // Helper function call for remove without needing to call a Node* in main.
    void remove(int id) {
        //Node* originalRoot = root;
        root = removeFunction(root, id);
    }
    // Method used to delete nodes from the tree.
    Node* removeFunction(Node* node, int id) {
        // Check to see if a tree exists.
        if (node == nullptr) {
            return nullptr;
        }
        // Iterate through loop - go left if need a smaller ID, go right if need a bigger ID
        if (id < node->idNum) {
            node->left = removeFunction(node->left, id);
        }
        else if (node->idNum < id) {
            node->right = removeFunction(node->right, id);
        }
        else if (node->idNum == id) {
            numNodes--;
            bool nodeIsRoot = false;
            if (id == root->idNum) {
                nodeIsRoot = true;
            }
            // If no children...
            if (node->left == nullptr && node->right == nullptr) {
                delete(node);
                // Root deleted
                if (nodeIsRoot) {
                    return nullptr;
                }
                else {
                    return root;
                }
            }
            // If only one child on left
            else if (node->left != nullptr && node->right == nullptr) {
                Node* tempNode = node->left;
                delete(node);
                node = tempNode;
                if (nodeIsRoot) {
                    return node;
                }
                else {
                    return root;
                }
            }
            // If only one child on right
            else if (node->left == nullptr && node->right != nullptr) {
                Node* tempNode = node->right;
                delete(node);
                node = tempNode;
                if (nodeIsRoot) {
                    return node;
                }
                else {
                    return root;
                }
            }
            // If two children
            else {
                Node* inorderSuccessor = findInorderSuccessor(node);
                node = inorderSuccessor;
                node->right = removeFunction(node->right, inorderSuccessor->idNum);
                numNodes++;
                return node;
            }
        }
    }
 */